package br.edu.fatecpg.authroom.data.local;

import androidx.room.*
import br.edu.fatecpg.authroom.data.local.Movie
import kotlinx.coroutines.flow.Flow

@Dao
interface MovieDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMovie(movie: Movie)

    @Update
    suspend fun updateMovie(movie: Movie)

    @Delete
    suspend fun deleteMovie(movie: Movie)

    @Query("SELECT * FROM movies_table WHERE userId = :userId ORDER BY id DESC")
    fun getMoviesByUser(userId: String): Flow<List<Movie>>

    @Query("UPDATE movies_table SET isWatched = :status WHERE id = :movieId")
    suspend fun updateWatchStatus(movieId: Int, status: Boolean)
}