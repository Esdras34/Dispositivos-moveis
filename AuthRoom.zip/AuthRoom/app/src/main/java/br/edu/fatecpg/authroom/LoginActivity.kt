package br.edu.fatecpg.authroom

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import br.edu.fatecpg.authroom.data.auth.AuthService

class LoginActivity : AppCompatActivity() {
    private val authService = AuthService()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        if (authService.isUserLoggedIn()) {
            startActivity(Intent(this, MainActivity::class.java))
            finish()
        }

        val btnLogin = findViewById<android.widget.Button>(R.id.btnLogin)
        val txtRegister = findViewById<android.widget.TextView>(R.id.txtRegister)
        val edtEmail = findViewById<android.widget.EditText>(R.id.edtEmail)
        val edtPassword = findViewById<android.widget.EditText>(R.id.edtPassword)

        btnLogin.setOnClickListener {
            val email = edtEmail.text.toString()
            val pass = edtPassword.text.toString()

            if (email.isNotEmpty() && pass.isNotEmpty()) {
                authService.login(email, pass) { success ->
                    if (success) {
                        startActivity(Intent(this, MainActivity::class.java))
                        finish()
                    } else {
                        Toast.makeText(this, "Erro ao entrar. Verifique os dados.", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }

        txtRegister.setOnClickListener {
            startActivity(Intent(this, RegisterActivity::class.java))
        }
    }
}