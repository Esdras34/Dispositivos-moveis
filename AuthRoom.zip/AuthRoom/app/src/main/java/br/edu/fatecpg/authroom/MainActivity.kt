package br.edu.fatecpg.authroom

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.browser.customtabs.CustomTabsIntent
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import br.edu.fatecpg.authroom.data.auth.AuthService
import br.edu.fatecpg.authroom.data.local.AppDatabase
import br.edu.fatecpg.authroom.data.repository.MovieRepository
import br.edu.fatecpg.authroom.databinding.ActivityMainBinding
import br.edu.fatecpg.authroom.ui.adapter.MovieAdapter
import br.edu.fatecpg.authroom.ui.viewmodel.MovieViewModel
import br.edu.fatecpg.authroom.ui.viewmodel.MovieViewModelFactory

import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import androidx.core.net.toUri
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val authService = AuthService()
    private lateinit var movieViewModel: MovieViewModel
    private lateinit var adapter: MovieAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (!authService.isUserLoggedIn()) {
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
            return
        }

        // 2. Configura a Tela
        binding = ActivityMainBinding.inflate(layoutInflater)
        enableEdgeToEdge()
        setContentView(binding.root)

        val userId = authService.getCurrentUserId() ?: ""

        val database = AppDatabase.getDatabase(this)
        val repository = MovieRepository(database.movieDao())
        val factory = MovieViewModelFactory(repository)
        movieViewModel = ViewModelProvider(this, factory)[MovieViewModel::class.java]

        adapter = MovieAdapter(
            onYoutubeClick = { url ->
                abrirYoutube(url)
            },
            onStatusClick = { movie ->
                movieViewModel.toggleWatchStatus(movie)
            },
            onEditClick = { movie ->
                showEditMovieDialog(movie)
            },
            onDeleteClick = { movie ->
                movieViewModel.deleteMovie(movie)
                Toast.makeText(this, "Filme excluído!", Toast.LENGTH_SHORT).show()
            }
        )

        binding.recyclerView.layoutManager = LinearLayoutManager(this)
        binding.recyclerView.adapter = adapter

        lifecycleScope.launch {
            movieViewModel.getMovies(userId).collectLatest { listaDeFilmes ->
                adapter.updateList(listaDeFilmes)
            }
        }

        binding.fabAddMovie.setOnClickListener {
            showAddMovieDialog(userId)
        }

        binding.btnLogout.setOnClickListener {
            authService.signOut()
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
        }

        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }

    private fun abrirYoutube(url: String) {
        try {
            val builder = CustomTabsIntent.Builder()
            val customTabsIntent = builder.build()
            customTabsIntent.launchUrl(this, url.toUri())
        } catch (e: Exception) {
            Toast.makeText(this, "Erro ao abrir o link", Toast.LENGTH_SHORT).show()
        }
    }

    private fun showAddMovieDialog(userId: String) {
        val dialogView = layoutInflater.inflate(R.layout.dialog_add_movie, null)
        val dialog = com.google.android.material.bottomsheet.BottomSheetDialog(this)
        dialog.setContentView(dialogView)

        val btnSave = dialogView.findViewById<android.widget.Button>(R.id.btnSaveMovie)
        val edtTitle = dialogView.findViewById<android.widget.EditText>(R.id.edtMovieTitle)
        val edtLink = dialogView.findViewById<android.widget.EditText>(R.id.edtYoutubeLink)

        btnSave.setOnClickListener {
            val title = edtTitle.text.toString()
            val link = edtLink.text.toString()

            if (title.isNotEmpty() && link.isNotEmpty()) {
                val newMovie = br.edu.fatecpg.authroom.data.local.Movie(
                    title = title,
                    youtubeLink = link,
                    isWatched = false,
                    userId = userId
                )

                movieViewModel.insertMovie(newMovie)

                Toast.makeText(this, "Filme adicionado!", Toast.LENGTH_SHORT).show()
                dialog.dismiss()
            } else {
                Toast.makeText(this, "Preencha todos os campos", Toast.LENGTH_SHORT).show()
            }
        }

        dialog.show()
    }

    private fun showEditMovieDialog(movie: br.edu.fatecpg.authroom.data.local.Movie) {
        val dialogView = layoutInflater.inflate(R.layout.dialog_add_movie, null)
        val dialog = com.google.android.material.bottomsheet.BottomSheetDialog(this)
        dialog.setContentView(dialogView)

        val btnSave = dialogView.findViewById<android.widget.Button>(R.id.btnSaveMovie)
        val edtTitle = dialogView.findViewById<android.widget.EditText>(R.id.edtMovieTitle)
        val edtLink = dialogView.findViewById<android.widget.EditText>(R.id.edtYoutubeLink)

        edtTitle.setText(movie.title)
        edtLink.setText(movie.youtubeLink)
        btnSave.text = "Atualizar Filme"

        btnSave.setOnClickListener {
            val title = edtTitle.text.toString()
            val link = edtLink.text.toString()

            if (title.isNotEmpty() && link.isNotEmpty()) {
                val updatedMovie = br.edu.fatecpg.authroom.data.local.Movie(
                    id = movie.id,
                    title = title,
                    youtubeLink = link,
                    isWatched = movie.isWatched,
                    userId = movie.userId
                )

                movieViewModel.updateMovie(updatedMovie)

                Toast.makeText(this, "Filme atualizado!", Toast.LENGTH_SHORT).show()
                dialog.dismiss()
            } else {
                Toast.makeText(this, "Preencha todos os campos", Toast.LENGTH_SHORT).show()
            }
        }

        dialog.show()
    }

}