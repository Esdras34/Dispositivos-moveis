package br.edu.fatecpg.authroom.ui.adapter;

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import br.edu.fatecpg.authroom.R
import br.edu.fatecpg.authroom.data.local.Movie

class MovieAdapter(
    private val onYoutubeClick: (String) -> Unit,
    private val onStatusClick: (Movie) -> Unit,
    private val onEditClick: (Movie) -> Unit,
    private val onDeleteClick: (Movie) -> Unit
) : RecyclerView.Adapter<MovieAdapter.MovieViewHolder>() {

    private var movieList = emptyList<Movie>()

    class MovieViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val title: TextView = view.findViewById(R.id.txtTitle)
        val status: TextView = view.findViewById(R.id.txtStatus)
        val btnYoutube: Button = view.findViewById(R.id.btnWatchVideo)
        val btnEdit: Button = view.findViewById(R.id.btnEdit)
        val btnDelete: Button = view.findViewById(R.id.btnDelete)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MovieViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_movie, parent, false)
        return MovieViewHolder(view)
    }

    override fun onBindViewHolder(holder: MovieViewHolder, position: Int) {
        val movie = movieList[position]
        holder.title.text = movie.title
        holder.status.text = if (movie.isWatched) "Status: Já Assisti" else "Status: Preciso Assistir"

        holder.btnYoutube.setOnClickListener { onYoutubeClick(movie.youtubeLink) }
        holder.itemView.setOnClickListener { onStatusClick(movie) }

        holder.btnEdit.setOnClickListener { onEditClick(movie) }
        holder.btnDelete.setOnClickListener { onDeleteClick(movie) }
    }

    override fun getItemCount(): Int = movieList.size

    fun updateList(newList: List<Movie>) {
        movieList = newList
        notifyDataSetChanged()
    }
}