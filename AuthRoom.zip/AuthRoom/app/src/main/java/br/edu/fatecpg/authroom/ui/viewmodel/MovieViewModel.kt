package br.edu.fatecpg.authroom.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import br.edu.fatecpg.authroom.data.local.Movie
import br.edu.fatecpg.authroom.data.repository.MovieRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.launch

class MovieViewModel(private val repository: MovieRepository) : ViewModel() {

    fun getMovies(userId: String): Flow<List<Movie>> {
        return repository.getMoviesByUser(userId)
    }

    fun insertMovie(movie: Movie) {
        viewModelScope.launch {
            repository.insertMovie(movie)
        }
    }

    fun updateMovie(movie: Movie) {
        viewModelScope.launch {
            repository.updateMovie(movie)
        }
    }

    fun deleteMovie(movie: Movie) {
        viewModelScope.launch {
            repository.deleteMovie(movie)
        }
    }

    fun toggleWatchStatus(movie: Movie) {
        viewModelScope.launch {
            repository.updateWatchStatus(movie.id, !movie.isWatched)
        }
    }
}