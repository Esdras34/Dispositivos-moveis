package br.edu.fatecpg.authroom

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import br.edu.fatecpg.authroom.data.auth.AuthService
import br.edu.fatecpg.authroom.databinding.ActivityRegisterBinding

class RegisterActivity : AppCompatActivity() {
    private lateinit var binding: ActivityRegisterBinding
    private val authService = AuthService()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRegisterBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnConfirmRegister.setOnClickListener {
            val email = binding.edtRegisterEmail.text.toString()
            val pass = binding.edtRegisterPassword.text.toString()
            val confirmPass = binding.edtConfirmPassword.text.toString()

            if (email.isNotEmpty() && pass.isNotEmpty()) {
                if (pass == confirmPass) {
                    authService.register(email, pass) { success ->
                        if (success) {
                            Toast.makeText(this, "Sucesso! Faça login.", Toast.LENGTH_SHORT).show()
                            finish()
                        } else {
                            Toast.makeText(this, "Erro ao cadastrar.", Toast.LENGTH_SHORT).show()
                        }
                    }
                } else {
                    Toast.makeText(this, "As senhas não conferem!", Toast.LENGTH_SHORT).show()
                }
            } else {
                Toast.makeText(this, "Preencha todos os campos.", Toast.LENGTH_SHORT).show()
            }
        }

        binding.txtBackToLogin.setOnClickListener {
            finish()
        }
    }
}