package br.edu.fatecpg.authroom.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "movies_table")
data class Movie(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,

    val title: String,

    val youtubeLink: String,

    val isWatched: Boolean = false,

    val userId: String
)