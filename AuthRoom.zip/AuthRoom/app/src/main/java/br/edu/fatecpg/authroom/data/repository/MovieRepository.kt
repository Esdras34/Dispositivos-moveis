package br.edu.fatecpg.authroom.data.repository;

import br.edu.fatecpg.authroom.data.local.Movie
import br.edu.fatecpg.authroom.data.local.MovieDao
import kotlinx.coroutines.flow.Flow

class MovieRepository(private val movieDao: MovieDao) {

    fun getMoviesByUser(userId: String): Flow<List<Movie>> {
        return movieDao.getMoviesByUser(userId)
    }

    suspend fun insertMovie(movie: Movie) {
        movieDao.insertMovie(movie)
    }

    suspend fun updateMovie(movie: Movie) {
        movieDao.updateMovie(movie)
    }

    suspend fun deleteMovie(movie: Movie) {
        movieDao.deleteMovie(movie)
    }

    suspend fun updateWatchStatus(movieId: Int, status: Boolean) {
        movieDao.updateWatchStatus(movieId, status)
    }
}